"use strict";
exports.id = 290;
exports.ids = [290];
exports.modules = {

/***/ 6329:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "R": () => (/* binding */ Categories)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./src/components/Category/Categories/Card/Card.jsx


const Card = ({ category  })=>{
    const { name , banner  } = category;
    return(/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
        href: `/shop`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
            className: "top-categories__item",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: banner,
                    className: "js-img",
                    alt: ""
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "top-categories__item-hover",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            children: name
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "browse products -"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icon-arrow-lg"
                        })
                    ]
                })
            ]
        })
    }));
};

;// CONCATENATED MODULE: ./src/components/Category/Categories/Categories.jsx


const Categories = ({ categories , isParent =true  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: categories.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: category.parent_id == 0 || !isParent ? /*#__PURE__*/ jsx_runtime_.jsx(Card, {
                    category: category
                }) : null
            })
        )
    }));
};


/***/ }),

/***/ 2917:
/***/ ((module) => {

module.exports = [];

/***/ })

};
;