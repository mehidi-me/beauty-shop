"use strict";
exports.id = 47;
exports.ids = [47];
exports.modules = {

/***/ 47:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Vx": () => (/* binding */ update),
/* harmony export */   "Od": () => (/* binding */ remove),
/* harmony export */   "IH": () => (/* binding */ add)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_1__);


const update = async (type, payload, curp, dispatch)=>{
    const quantity = type == "plus" ? curp.qty + 1 : curp.qty - 1;
    if (quantity >= 1) {
        try {
            const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post("carts/change-quantity", {
                temp_user_id: localStorage.getItem("uid"),
                cart_id: curp.cart_id,
                type
            });
            console.log(res);
            if (res.data) {
                if (res.data.success) {
                    dispatch(payload);
                //toast.success(res.data.message);
                } else {
                    react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error(res.data.message);
                }
            }
            return res;
        } catch (error) {
            console.log(error);
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error("Something wrong try again!");
        }
    }
};
const remove = async (id, dispatch)=>{
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post("carts/destroy", {
            temp_user_id: localStorage.getItem("uid"),
            cart_id: id
        });
        if (res.data) {
            if (res.data.success) {
                dispatch({
                    type: "REMOVE_TO_CART",
                    payload: {
                        id
                    }
                });
                react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.success(res.data.message);
            } else {
                react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error(res.data.message);
            }
        }
    } catch (error) {
        console.log(error);
        react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error("Something wrong try again!");
    }
};
const add = async (qty, variation_id, dispatch)=>{
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().post("carts/add", {
            temp_user_id: localStorage.getItem("uid"),
            variation_id,
            qty
        });
        if (res.data) {
            if (res.data.success) {
                dispatch({
                    type: "UPDATE_CART",
                    payload: res.data.data.data
                });
                react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.success(res.data.message);
            } else {
                react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error(res.data.message);
            }
        }
    } catch (error) {
        console.log(error);
        react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error("Something wrong try again!");
    }
};



/***/ })

};
;