"use strict";
exports.id = 654;
exports.ids = [654];
exports.modules = {

/***/ 2654:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartContext": () => (/* binding */ CartContext),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var storeData_reducer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2394);
/* harmony import */ var storeData_initialState__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5926);
/* harmony import */ var storeData_AppContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5698);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8890);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(nextjs_progressbar__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_8__]);
uuid__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];











(axios__WEBPACK_IMPORTED_MODULE_2___default().defaults.baseURL) = "http://admin.duause.com/api/v1";
const CartContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const MyApp = ({ Component , pageProps  })=>{
    const { 0: cart , 1: setCart  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const { 0: state , 1: dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(storeData_reducer__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, storeData_initialState__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z);
    const getCatAndPro = async ()=>{
        const res = await axios__WEBPACK_IMPORTED_MODULE_2___default().get("product/search");
        if (res.data) {
            if (res.data.success) {
                const category = res.data.rootCategories.data;
                const allProducts = res.data.products.data;
                if (category && allProducts) {
                    console.log(allProducts);
                    dispatch({
                        type: "GET_ALL_CATEGORY_AND_PRODUCTS",
                        payload: {
                            category,
                            allProducts
                        }
                    });
                } else {
                    window.location.reload();
                }
            } else {
                window.location.reload();
            }
        } else {
            window.location.reload();
        }
        setLoading(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getCatAndPro();
        const cartData = JSON.parse(localStorage.getItem("cartdata"));
        const whishlist = JSON.parse(localStorage.getItem("whishlist"));
        const user = JSON.parse(localStorage.getItem("user"));
        const recentView = JSON.parse(localStorage.getItem("recentview"));
        const uid = localStorage.getItem("uid");
        if (!uid) {
            localStorage.setItem("uid", (0,uuid__WEBPACK_IMPORTED_MODULE_8__.v1)());
        }
        if (user) {
            if (user.id) {
                (axios__WEBPACK_IMPORTED_MODULE_2___default().defaults.headers) = {
                    Authorization: `Bearer ${user.access_token}`
                };
                dispatch({
                    type: "SET_LOGIN",
                    payload: user
                });
            }
        }
        if (cartData) {
            if (cartData.length) {
                dispatch({
                    type: "SET_CART_DATA",
                    payload: cartData
                });
            }
        }
        if (whishlist) {
            if (whishlist.length) {
                dispatch({
                    type: "SET_WHISHLIST_DATA",
                    payload: whishlist
                });
            }
        }
    }, []);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(storeData_AppContext__WEBPACK_IMPORTED_MODULE_4__/* ["default"].Provider */ .Z.Provider, {
        value: {
            state,
            dispatch,
            loading
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(CartContext.Provider, {
            value: {
                cart,
                setCart
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((nextjs_progressbar__WEBPACK_IMPORTED_MODULE_5___default()), {
                    color: "#744d2e",
                    startPosition: 0.3,
                    stopDelayMs: 200,
                    height: 3,
                    showOnShallow: true
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, {
                    theme: "dark"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

});

/***/ }),

/***/ 5698:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const AppContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createContext();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppContext);


/***/ }),

/***/ 5926:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const initialState = {
    category: [],
    allProducts: [],
    subCategory: [],
    childCategory: [],
    cartData: [],
    whishlist: [],
    user: null,
    generalSettings: {
    },
    siteData: {
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initialState);


/***/ }),

/***/ 2394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const addToWishlist = (state, payload)=>{
    const newData = [
        ...state.whishlist,
        payload
    ];
    localStorage.setItem("whishlist", JSON.stringify(newData));
    return {
        ...state,
        whishlist: newData
    };
};
const removeWishlist = (state, id)=>{
    const newData = state.whishlist.filter((v)=>v.id != id
    );
    localStorage.setItem("whishlist", JSON.stringify(newData));
    return {
        ...state,
        whishlist: newData
    };
};
const addToCart = (state, payload)=>{
    const newData = [
        ...state.cartData,
        payload
    ];
    localStorage.setItem("cartdata", JSON.stringify(newData));
    return {
        ...state,
        cartData: newData
    };
};
// cart update all time *********//
const updateCart = (state, payload)=>{
    localStorage.setItem("cartdata", JSON.stringify(payload));
    return {
        ...state,
        cartData: payload
    };
};
const removeCart = (state, id)=>{
    const newData = state.cartData.filter((v)=>v.cart_id != id
    );
    localStorage.setItem("cartdata", JSON.stringify(newData));
    return {
        ...state,
        cartData: newData
    };
};
const increaseQty = (state, id)=>{
    const newData = state.cartData.map((data)=>{
        if (data.product_id == id) {
            return {
                ...data,
                qty: data.qty + 1
            };
        }
        return data;
    });
    localStorage.setItem("cartdata", JSON.stringify(newData));
    return {
        ...state,
        cartData: newData
    };
};
const decreaseQty = (state, id)=>{
    const newData = state.cartData.map((data)=>{
        if (data.product_id == id) {
            return {
                ...data,
                qty: data.qty - 1
            };
        }
        return data;
    }).filter((v)=>v.qty != 0
    );
    localStorage.setItem("cartdata", JSON.stringify(newData));
    return {
        ...state,
        cartData: newData
    };
};
const login = (state, payload)=>{
    localStorage.setItem("user", JSON.stringify(payload));
    return {
        ...state,
        user: payload
    };
};
const logout = (state)=>{
    localStorage.removeItem("user");
    return {
        ...state,
        user: null
    };
};
const setSiteData = (state, data)=>{
    let obj = {
    };
    data.map((v)=>{
        switch(v.type){
            case "footer_logo":
                obj = {
                    ...obj,
                    footer_logo: v.value
                };
                break;
            case "about_us_description":
                obj = {
                    ...obj,
                    about_us_description: v.value
                };
                break;
            case "contact_address":
                obj = {
                    ...obj,
                    contact_address: v.value
                };
                break;
            case "contact_email":
                obj = {
                    ...obj,
                    contact_email: v.value
                };
                break;
            case "contact_phone":
                obj = {
                    ...obj,
                    contact_phone: v.value
                };
                break;
            case "facebook_link":
                obj = {
                    ...obj,
                    facebook_link: v.value
                };
                break;
            case "twitter_link":
                obj = {
                    ...obj,
                    twitter_link: v.value
                };
                break;
            case "instagram_link":
                obj = {
                    ...obj,
                    instagram_link: v.value
                };
                break;
            case "youtube_link":
                obj = {
                    ...obj,
                    youtube_link: v.value
                };
                break;
            case "linkedin_link":
                obj = {
                    ...obj,
                    linkedin_link: v.value
                };
                break;
            case "website_name":
                obj = {
                    ...obj,
                    website_name: v.value
                };
                break;
            case "site_motto":
                obj = {
                    ...obj,
                    site_motto: v.value
                };
                break;
            case "site_icon":
                obj = {
                    ...obj,
                    site_icon: v.value
                };
                break;
            case "meta_title":
                obj = {
                    ...obj,
                    meta_title: v.value
                };
                break;
            case "meta_description":
                obj = {
                    ...obj,
                    meta_description: v.value
                };
                break;
            case "meta_keywords":
                obj = {
                    ...obj,
                    meta_keywords: v.value
                };
                break;
            case "meta_image":
                obj = {
                    ...obj,
                    meta_image: v.value
                };
                break;
            case "system_logo_white":
                obj = {
                    ...obj,
                    logo: v.value
                };
                break;
            default:
                break;
        }
    });
    return {
        ...state,
        siteData: obj
    };
};
const reducer = (state, action)=>{
    switch(action.type){
        case "GET_ALL_CATEGORY_AND_PRODUCTS":
            return {
                ...state,
                ...action.payload
            };
            break;
        case "SET_SETTING":
            return {
                ...state,
                generalSettings: action.payload
            };
            break;
        case "ADD_TO_WHISHLIST":
            return addToWishlist(state, action.payload);
            break;
        case "ADD_TO_CART":
            return addToCart(state, action.payload);
            break;
        case "UPDATE_CART":
            return updateCart(state, action.payload);
            break;
        case "SET_CART_DATA":
            return {
                ...state,
                cartData: action.payload
            };
            break;
        case "SET_WHISHLIST_DATA":
            return {
                ...state,
                whishlist: action.payload
            };
            break;
        case "REMOVE_TO_WHISHLIST":
            return removeWishlist(state, action.payload.id);
            break;
        case "REMOVE_TO_CART":
            return removeCart(state, action.payload.id);
            break;
        case "INCREASE_QTY":
            return increaseQty(state, action.payload.id);
            break;
        case "DECREASE_QTY":
            return decreaseQty(state, action.payload.id);
            break;
        case "CLEAR_CART":
            return {
                ...state,
                cartData: []
            };
            break;
        case "LOGIN":
            return login(state, action.payload);
            break;
        case "SET_LOGIN":
            return {
                ...state,
                user: action.payload
            };
            break;
        case "LOG_OUT":
            return logout(state);
        case "SET_SITE_DATA":
            return setSiteData(state, action.payload);
            break;
        default:
            return state;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (reducer);


/***/ })

};
;