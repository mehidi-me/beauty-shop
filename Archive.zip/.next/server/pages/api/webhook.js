"use strict";
(() => {
var exports = {};
exports.id = 538;
exports.ids = [538];
exports.modules = {

/***/ 8174:
/***/ ((module) => {

module.exports = require("stripe");

/***/ }),

/***/ 7526:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "stripe"
var external_stripe_ = __webpack_require__(8174);
var external_stripe_default = /*#__PURE__*/__webpack_require__.n(external_stripe_);
;// CONCATENATED MODULE: external "micro"
const external_micro_namespaceObject = require("micro");
;// CONCATENATED MODULE: ./src/pages/api/webhook/index.js


const stripe = new (external_stripe_default())(process.env.STRIPE_SECRET_KEY);
const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    if (req.method === "POST") {
        let event;
        try {
            // 1. Retrieve the event by verifying the signature using the raw body and secret
            const rawBody = await (0,external_micro_namespaceObject.buffer)(req);
            const signature = req.headers["stripe-signature"];
            event = stripe.webhooks.constructEvent(rawBody.toString(), signature, process.env.STRIPE_WEBHOOK_SECRET);
        } catch (err) {
            console.log(`❌ Error message: ${err.message}`);
            res.status(400).send(`Webhook Error: ${err.message}`);
            return;
        }
        // Successfully constructed event
        console.log("✅ Success:", event.id);
        // 2. Handle event type (add business logic here)
        if (event.type === "checkout.session.completed") {
            console.log(`💰  Payment received!`);
        } else {
            console.warn(`🤷‍♀️ Unhandled event type: ${event.type}`);
        }
        // 3. Return a response to acknowledge receipt of the event.
        res.json({
            received: true
        });
    } else {
        res.setHeader("Allow", "POST");
        res.status(405).end("Method Not Allowed");
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7526));
module.exports = __webpack_exports__;

})();