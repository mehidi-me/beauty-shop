"use strict";
(() => {
var exports = {};
exports.id = 360;
exports.ids = [360];
exports.modules = {

/***/ 4057:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ ProductDetails)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var data_product_product__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2136);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var data_social__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5941);
/* harmony import */ var _Reviews_Reviews__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5377);
/* harmony import */ var _ReviewForm_ReviewFrom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2132);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var storeData_AppContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5698);
/* harmony import */ var components_Cart_updateCart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(47);
/* harmony import */ var pages_app__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2654);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(264);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(html_react_parser__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([pages_app__WEBPACK_IMPORTED_MODULE_11__]);
pages_app__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];














const ProductDetails = ({ product , slug  })=>{
    var ref;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const { cart , setCart  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(pages_app__WEBPACK_IMPORTED_MODULE_11__.CartContext);
    const { state: { whishlist , cartData  } , dispatch ,  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(storeData_AppContext__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z);
    const socialLinks = [
        ...data_social__WEBPACK_IMPORTED_MODULE_4__
    ];
    const products = [
        ...data_product_product__WEBPACK_IMPORTED_MODULE_1__
    ];
    // const [product, setProduct] = useState(null);
    const { 0: addedInCart , 1: setAddedInCart  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    // useEffect(() => {
    //   if (router.query.id) {
    //     const data = products.find((pd) => pd.id === router.query.id);
    //     setProduct(data);
    //   }
    // }, [router.query.id]);
    // useEffect(() => {
    //   if (product) {
    //     setAddedInCart(Boolean(cart?.find((pd) => pd.id === product.id)));
    //   }
    // }, [product, cart]);
    const { 0: quantity , 1: setQuantity  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(1);
    const { 0: tab , 1: setTab  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(2);
    const { 0: activeColor , 1: setActiveColor  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(2);
    const { 0: nav1 , 1: setNav1  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const { 0: nav2 , 1: setNav2  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: uloading , 1: setuLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const currentProduct = cartData.find((v)=>v.product_id == product.id
    );
    const handleAddToCart = async ()=>{
        setLoading(true);
        await (0,components_Cart_updateCart__WEBPACK_IMPORTED_MODULE_10__/* .add */ .IH)(quantity, product.variations[0].id, dispatch);
        setLoading(false);
    };
    const removeCart = async ()=>{
        setLoading(true);
        await (0,components_Cart_updateCart__WEBPACK_IMPORTED_MODULE_10__/* .remove */ .Od)(currentProduct.cart_id, dispatch);
        setLoading(false);
        setQuantity(1);
    };
    const addToWhishlist = ()=>{
        const payload = {
            id: product.id,
            name: product.name,
            price: product.base_discounted_price,
            image: product.thumbnail_image,
            slug: product.slug
        };
        dispatch({
            type: "ADD_TO_WHISHLIST",
            payload
        });
        react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.success("Successfully wishlist added!");
    };
    const inWishlist = Boolean(whishlist.find((v)=>v.id == product.id
    ));
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (currentProduct) {
            setQuantity(currentProduct.qty);
        }
        console.log(product);
        if (!product.stock) {
            router.push("/");
            react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.error("Product Stock Out!");
        }
    }, [
        currentProduct
    ]);
    const { 0: allReviews , 1: setAllReviews  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const { 0: rloading , 1: setrLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const getReview = async ()=>{
        setrLoading(true);
        const res = await axios__WEBPACK_IMPORTED_MODULE_12___default().get("product/reviews/" + product.id);
        if (res.data.success) {
            console.log(res);
            setAllReviews(res.data.data);
        }
        setrLoading(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getReview();
    }, []);
    if (!product) return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    }));
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "product",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "wrapper",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "product-content",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "product-slider",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "product-slider__main",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            fade: true,
                                            asNavFor: nav2,
                                            arrows: false,
                                            lazyLoad: true,
                                            ref: (slider1)=>setNav1(slider1)
                                            ,
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "product-slider__main-item",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "products-item__type",
                                                            children: [
                                                                product.isSale && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "products-item__sale",
                                                                    children: "sale"
                                                                }),
                                                                product.isNew && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "products-item__new",
                                                                    children: "new"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            src: product.thumbnail_image,
                                                            alt: "product"
                                                        })
                                                    ]
                                                }),
                                                product.photos.map((img, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "product-slider__main-item",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "products-item__type",
                                                                children: [
                                                                    product.isSale && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "products-item__sale",
                                                                        children: "sale"
                                                                    }),
                                                                    product.isNew && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "products-item__new",
                                                                        children: "new"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                src: img,
                                                                alt: "product"
                                                            })
                                                        ]
                                                    }, index)
                                                )
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "product-slider__nav",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            arrows: false,
                                            asNavFor: nav1,
                                            ref: (slider2)=>setNav2(slider2)
                                            ,
                                            slidesToShow: 4,
                                            swipeToSlide: true,
                                            focusOnSelect: true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "product-slider__nav-item",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: product.thumbnail_image,
                                                        alt: "product"
                                                    })
                                                }),
                                                product.photos.map((img, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "product-slider__nav-item",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            src: img,
                                                            alt: "product"
                                                        })
                                                    }, index)
                                                )
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "product-info",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        children: product.name
                                    }),
                                    product.stock ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "product-stock",
                                        children: "in stock"
                                    }) : "",
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "product-num",
                                        children: [
                                            "SKU: ",
                                            product.productNumber
                                        ]
                                    }),
                                    product.base_price != product.base_discounted_price ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "product-price",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    "$",
                                                    product.base_price
                                                ]
                                            }),
                                            "$",
                                            product.base_discounted_price
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "product-price",
                                        children: [
                                            "$",
                                            product.base_price
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: product.content
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "contacts-info__social",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "Find us here:"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                children: socialLinks.map((social, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: social.path,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                className: social.icon ? social.icon : ""
                                                            })
                                                        })
                                                    }, index)
                                                )
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "product-options",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "product-info__color",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: "Color:"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                        children: product === null || product === void 0 ? void 0 : (ref = product.colors) === null || ref === void 0 ? void 0 : ref.map((color, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                onClick: ()=>setActiveColor(index)
                                                                ,
                                                                className: activeColor === index ? "active" : "",
                                                                style: {
                                                                    backgroundColor: color
                                                                }
                                                            }, index)
                                                        )
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "product-info__quantity",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "product-info__quantity-title",
                                                        children: "Quantity:"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "counter-box",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                onClick: async ()=>{
                                                                    if (currentProduct) {
                                                                        setuLoading(true);
                                                                        await (0,components_Cart_updateCart__WEBPACK_IMPORTED_MODULE_10__/* .update */ .Vx)("minus", {
                                                                            type: "DECREASE_QTY",
                                                                            payload: {
                                                                                id: product.id
                                                                            }
                                                                        }, currentProduct, dispatch);
                                                                        setuLoading(false);
                                                                    } else {
                                                                        if (quantity > 1) {
                                                                            setQuantity(quantity - 1);
                                                                        }
                                                                    }
                                                                },
                                                                disabled: uloading,
                                                                className: "counter-link counter-link__prev",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                    className: "icon-arrow"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "text",
                                                                className: "counter-input",
                                                                disabled: true,
                                                                value: quantity
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                onClick: async ()=>{
                                                                    if (currentProduct) {
                                                                        setuLoading(true);
                                                                        await (0,components_Cart_updateCart__WEBPACK_IMPORTED_MODULE_10__/* .update */ .Vx)("plus", {
                                                                            type: "INCREASE_QTY",
                                                                            payload: {
                                                                                id: product.id
                                                                            }
                                                                        }, currentProduct, dispatch);
                                                                        setuLoading(false);
                                                                    } else {
                                                                        setQuantity(quantity + 1);
                                                                    }
                                                                },
                                                                disabled: uloading,
                                                                className: "counter-link counter-link__next",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                    className: "icon-arrow"
                                                                })
                                                            }),
                                                            uloading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                src: "/assets/img/icons/loading.gif",
                                                                width: 25
                                                            }) : null
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "product-buttons",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                // disabled={currentProduct ? true : false}
                                                onClick: currentProduct ? removeCart : handleAddToCart,
                                                className: "btn btn-icon",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fas fa-shopping-bag"
                                                    }),
                                                    loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: "/assets/img/icons/loading.gif",
                                                        width: 25
                                                    }) : currentProduct ? "remove" : "add cart"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                className: "btn btn-grey btn-icon",
                                                disabled: inWishlist,
                                                onClick: addToWhishlist,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "icon-heart",
                                                        style: inWishlist ? {
                                                            color: "red"
                                                        } : {
                                                        }
                                                    }),
                                                    " ",
                                                    "wish"
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "product-detail",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "tab-wrap product-detail-tabs",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "nav-tab-list tabs pd-tab",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: tab === 1 ? "active" : "",
                                            onClick: ()=>setTab(1)
                                            ,
                                            children: "Description"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: tab === 2 ? "active" : "",
                                            onClick: ()=>setTab(2)
                                            ,
                                            children: "Reviews"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "box-tab-cont",
                                    children: [
                                        tab === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "tab-cont",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: html_react_parser__WEBPACK_IMPORTED_MODULE_13___default()(product.description)
                                            })
                                        }),
                                        tab === 2 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "tab-cont product-reviews",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Reviews_Reviews__WEBPACK_IMPORTED_MODULE_5__/* .Reviews */ .Z, {
                                                    allReviews: allReviews,
                                                    loading: rloading
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ReviewForm_ReviewFrom__WEBPACK_IMPORTED_MODULE_6__/* .ReviewFrom */ .Y, {
                                                    pid: product.id,
                                                    getReview: getReview
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    }));
};

});

/***/ }),

/***/ 2132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Y": () => (/* binding */ ReviewFrom)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "react-simple-star-rating"
const external_react_simple_star_rating_namespaceObject = require("react-simple-star-rating");
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./src/storeData/AppContext.js
var AppContext = __webpack_require__(5698);
;// CONCATENATED MODULE: ./src/components/Product/ReviewForm/ReviewFrom.jsx







const ReviewFrom = ({ pid , getReview  })=>{
    const { state: { user  } ,  } = (0,external_react_.useContext)(AppContext/* default */.Z);
    const router = (0,router_.useRouter)();
    const { 0: rating , 1: setRating  } = (0,external_react_.useState)(0);
    const { 0: comment , 1: setComment  } = (0,external_react_.useState)("");
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    // Catch Rating value
    const handleRating = (rate)=>{
        setRating(rate);
        console.log(rate / 20);
    };
    const submitReview = async (e)=>{
        e.preventDefault();
        if (user) {
            if (!rating) {
                return external_react_toastify_.toast.warning("Select your rating!");
            }
            if (!comment) {
                return external_react_toastify_.toast.warning("Enter your review!");
            }
            setLoading(true);
            const res = await external_axios_default().post("user/review/submit", {
                product_id: pid,
                rating: rating / 20,
                comment
            });
            if (res.data.success) {
                external_react_toastify_.toast.success(res.data.message);
                getReview();
            }
            setLoading(false);
        } else {
            external_react_toastify_.toast.warning("Please Login Frist!");
            router.push({
                pathname: "/login",
                query: {
                    pathname: router.asPath
                }
            });
        }
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "product-detail__form post-comment__form",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                onSubmit: submitReview,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: "leave a review"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Your email address will not be published."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "rating",
                        "data-id": "rating_1",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_simple_star_rating_namespaceObject.Rating, {
                            onClick: handleRating,
                            ratingValue: rating,
                            fillColor: "#cfc819",
                            size: "20px",
                            emptyColor: "#fff"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "box-field box-field__textarea",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                            required: true,
                            className: "form-control",
                            placeholder: "Enter your review",
                            onChange: (e)=>setComment(e.target.value)
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "btn",
                        type: "submit",
                        disabled: loading,
                        style: {
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center"
                        },
                        children: loading ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/assets/img/icons/loading.gif",
                            width: 30
                        }) : "send"
                    })
                ]
            })
        })
    }));
};


/***/ }),

/***/ 5377:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Reviews)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/components/Product/Reviews/Card/Card.jsx

const Card = ({ review  })=>{
    const { user , time , rating , comment  } = review;
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "review-item",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "review-item__head",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "review-item__author",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/assets/img/comment-author1.jpg",
                                    className: "js-img",
                                    alt: "author"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "review-item__name",
                                    children: user.name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "review-item__date",
                                    children: time
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "review-item__rating",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                className: "star-rating",
                                children: [
                                    ...Array(rating)
                                ].map((star, index)=>{
                                    return(/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "icon-star"
                                        })
                                    }, index));
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "review-item__content",
                    children: comment
                })
            ]
        })
    }));
};

;// CONCATENATED MODULE: ./src/components/Product/Reviews/Reviews.jsx




const Reviews = ({ pid , allReviews , loading  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "product-detail__items",
            children: [
                allReviews.map((review, index)=>/*#__PURE__*/ jsx_runtime_.jsx(Card, {
                        review: review
                    }, index)
                ),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        display: "flex",
                        justifyContent: "center",
                        paddingTop: "30px"
                    },
                    children: loading ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/assets/img/icons/loading.gif",
                        width: 80
                    }) : !allReviews.length ? /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: "No Review available!"
                    }) : null
                })
            ]
        })
    }));
};


/***/ }),

/***/ 2546:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_shared_MostViewed_MostViewed__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5918);
/* harmony import */ var components_Product_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4057);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var layout_PublicLayout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2506);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_shared_MostViewed_MostViewed__WEBPACK_IMPORTED_MODULE_1__, components_Product_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__, layout_PublicLayout__WEBPACK_IMPORTED_MODULE_4__]);
([components_shared_MostViewed_MostViewed__WEBPACK_IMPORTED_MODULE_1__, components_Product_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__, layout_PublicLayout__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);





const breadcrumbsData = [
    {
        label: "Home",
        path: "/"
    },
    {
        label: "Shop",
        path: "/shop"
    },
    {
        label: "Product",
        path: "/product"
    }, 
];
const SingleProductPage = ({ product , slug  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(layout_PublicLayout__WEBPACK_IMPORTED_MODULE_4__/* .PublicLayout */ .Y, {
        breadcrumb: breadcrumbsData,
        breadcrumbTitle: "Shop",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Product_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__/* .ProductDetails */ .f, {
                product: product,
                slug: slug
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_shared_MostViewed_MostViewed__WEBPACK_IMPORTED_MODULE_1__/* .MostViewed */ .o, {
                additionalClass: "product-viewed",
                pid: product ? product.id : 0
            })
        ]
    }));
};
async function getServerSideProps(context) {
    const { id  } = context.params;
    const res = await axios__WEBPACK_IMPORTED_MODULE_3___default().get("product/details/" + id);
    //const data = await res.json();
    //console.log(res);
    if (res.data.success) {
        const product = res.data.data;
        return {
            props: {
                product,
                id
            }
        };
    }
    return {
        props: {
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SingleProductPage);

});

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 264:
/***/ ((module) => {

module.exports = require("html-react-parser");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 8890:
/***/ ((module) => {

module.exports = require("nextjs-progressbar");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,848,654,959,506,136,47,969,493,914,918], () => (__webpack_exec__(2546)));
module.exports = __webpack_exports__;

})();