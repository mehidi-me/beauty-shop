const initialState = {
  category: [],
  allProducts: [],
  subCategory: [],
  childCategory: [],
  cartData: [],
  whishlist: [],
  user: null,
  generalSettings: {},
  siteData: {},
};

export default initialState;
